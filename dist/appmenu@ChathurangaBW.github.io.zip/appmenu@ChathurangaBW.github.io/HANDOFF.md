# AppMenu — OpenCode Handoff

## Project Identity

**AppMenu** is a macOS-style global menu bar GNOME Shell extension. Zero external daemons. Supports GNOME 45–50.

- **Repo**: `https://github.com/ChathurangaBW/AppMenu`
- **Local path**: `/home/sniffer/AppMenu`
- **UUID**: `appmenu@ChathurangaBW.github.io`
- **Current version**: v5.5 (pending release)
- **License**: GPL-3.0

## GitHub Access

Use the locally authenticated `gh` CLI for GitHub operations. Never store tokens
in this handoff, repository files, release artifacts, or Git remote URLs.

## Key Files

| File | Purpose |
|---|---|
| `metadata.json` | Extension UUID, version, shell versions |
| `extension.js` | Main entry point |
| `menuManager.js` | Core menu bar logic |
| `realMenuManager.js` | dbusmenu / org.gtk.Actions real menus |
| `searchDialog.js` | Spotlight-style search |
| `userSwitcher.js` | Fast user switching |
| `workspaceIndicator.js` | Workspace nav dots |
| `recentItemsSubmenu.js` | Recent files/items |
| `prefs.js` | Preferences UI |
| `schemas/org.gnome.shell.extensions.appmenu.gschema.xml` | GSettings schema |
| `po/appmenu.pot` / `po/en.po` | Translations |
| `install.sh` | Install script (user/system, `--clean-stale`, `--prefix=`) |
| `uninstall.sh` | Uninstall script |
| `scripts/build-packages.sh` | Builds all release artifacts |
| `build-locale.py` / `build-locale.sh` | Compile translations |

## Build & Release

```bash
cd /home/sniffer/AppMenu

# Build all packages (zip, .run, .bin, .deb)
export APPMENU_VERSION=5.5
bash scripts/build-packages.sh

# Output goes to dist/:
#   AppMenu-e.g.o-upload-v5.5.zip      (extensions.gnome.org)
#   AppMenu-v5.5.zip                    (source snapshot)
#   appmenu@ChathurangaBW.github.io.zip (manual install)
#   AppMenu-v5.5-linux.run              (self-extracting installer)
#   AppMenu-v5.5-linux.bin              (same, .bin extension)
#   appmenu_5.5_all.deb                 (Debian/Ubuntu package)
```

## Release on GitHub

```bash
# Create tag and release
V=5.5
git tag -a v$V -m "v$V description"
git push origin v$V
gh release create v$V --repo ChathurangaBW/AppMenu --draft --title "AppMenu v$V" --notes "Release notes"

# Upload all 6 assets
gh release upload v$V \
  dist/AppMenu-e.g.o-upload-v$V.zip \
  dist/appmenu@ChathurangaBW.github.io.zip \
  dist/AppMenu-v$V-linux.run \
  dist/AppMenu-v$V-linux.bin \
  dist/appmenu_${V}_all.deb \
  dist/AppMenu-v$V.zip \
  --repo ChathurangaBW/AppMenu --clobber

# Publish
gh release edit v$V --repo ChathurangaBW/AppMenu --draft=false --latest
```

## Install

```bash
./install.sh                      # user install (~/.local/share/...)
./install.sh --system             # system install (/usr/local/share/...)
./install.sh --system --prefix=/usr  # distro install
./install.sh --clean-stale        # auto-remove stale copies
```

## Architecture Notes

- **Hybrid approach**: Tries real dbusmenu first (`realMenuManager.js`), falls back to synthetic actions (`menuManager.js`) when no exported menu exists
- **i18n**: `_()` wrapper in `i18n.js`. PO files in `po/`, compiled MO in `locale/`
- **i18n fix**: `i18n.js` must be present in installed extension dir. Without it, GNOME Shell throws "Unable to load i18n.js" which cascades to extension failure. Stale copies without `i18n.js` are detected by `install.sh --clean-stale`
- **Schema**: Must compile with `glib-compile-schemas schemas/` before packaging. `build-packages.sh` does this

## Next Priorities (for v5.5+)

- Bug fixes, window-list polish
- Translations: currently only `en`; `po/appmenu.pot` is the template
- Testing: GNOME Shell 45–50 compatibility verification
