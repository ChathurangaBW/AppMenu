#!/bin/bash

EXTENSION_UUID="appmenu@ChathurangaBW"
EXTENSION_DIR="$HOME/.local/share/gnome-shell/extensions/$EXTENSION_UUID"
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "--------------------------------------------------"
echo "Installing AppMenu..."
echo "--------------------------------------------------"

echo "Clearing old structures..."
rm -rf "$EXTENSION_DIR"
mkdir -p "$EXTENSION_DIR"

echo "Copying extension files..."
cp -rv "$SOURCE_DIR/metadata.json" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/extension.js" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/menuManager.js" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/recentItemsSubmenu.js" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/documentTooltip.js" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/userSwitcher.js" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/prefs.js" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/stylesheet.css" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/actions" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/menus" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/icons" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/icons.json" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/uninstall.sh" "$EXTENSION_DIR/"
cp -rv "$SOURCE_DIR/schemas" "$EXTENSION_DIR/"

echo "Compiling GSettings schemas..."
glib-compile-schemas "$EXTENSION_DIR/schemas/"

echo "--------------------------------------------------"
echo "Installation complete!"
echo "Restart your desktop session (Logout/Login) to clear cache."
echo "--------------------------------------------------"
